// Função corrigida para adicionar assinaturas visuais ao PDF (SEM caracteres %P)
function adicionarAssinaturasAoPDF(doc, y) {
    // Carregar assinaturas salvas
    const assinLocador = assinaturaLocador || JSON.parse(localStorage.getItem('assinatura_locador') || 'null');
    const assinLocatario = assinaturaLocatario || JSON.parse(localStorage.getItem('assinatura_locatario') || 'null');
    
    // Limpar e validar dados das assinaturas
    const dadosLocadorLimpos = assinLocador && assinLocador.data ? limparDadosBase64(assinLocador.data) : null;
    const dadosLocatarioLimpos = assinLocatario && assinLocatario.data ? limparDadosBase64(assinLocatario.data) : null;
    
    // Se não há assinaturas válidas, não adicionar seção
    if (!dadosLocadorLimpos && !dadosLocatarioLimpos) {
        console.log('Nenhuma assinatura válida encontrada - não adicionando seção ao PDF');
        return y;
    }
    
    const pageHeight = doc.internal.pageSize.height;
    
    // Verificar se precisa de nova página
    if (y > pageHeight - 100) {
        doc.addPage();
        y = 20;
    }
    
    // Adicionar separador limpo (SEM caracteres %P)
    y += 10;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('ASSINATURAS DIGITAIS', 105, y, { align: 'center' });
    y += 15;
    
    // Data e hora
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    const dataHora = `Data: ${new Date().toLocaleDateString('pt-BR')} - Hora: ${new Date().toLocaleTimeString('pt-BR')}`;
    doc.text(dataHora, 105, y, { align: 'center' });
    y += 20;
    
    // Assinatura do Locador APENAS se válida
    if (dadosLocadorLimpos) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(12);
        doc.text('LOCADOR:', 15, y);
        y += 10;
        
        try {
            // Usar dados limpos e validados
            const imagemCompleta = 'data:image/png;base64,' + dadosLocadorLimpos;
            doc.addImage(imagemCompleta, 'PNG', 15, y, 80, 25);
            y += 30;
            console.log('Assinatura do locador adicionada com sucesso ao PDF');
        } catch (error) {
            console.error('Erro ao adicionar assinatura do locador:', error);
            doc.setFont('helvetica', 'normal');
            doc.text('____________________________________________', 15, y);
            y += 5;
            doc.text('[ASSINATURA DIGITAL DO LOCADOR APLICADA]', 15, y);
            y += 15;
        }
        
        // Linha de separação
        doc.line(15, y, 195, y);
        y += 5;
    }
    
    // Assinatura do Locatário APENAS se válida
    if (dadosLocatarioLimpos) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(12);
        doc.text('LOCATÁRIO:', 15, y);
        y += 10;
        
        try {
            // Usar dados limpos e validados
            const imagemCompleta = 'data:image/png;base64,' + dadosLocatarioLimpos;
            doc.addImage(imagemCompleta, 'PNG', 15, y, 80, 25);
            y += 30;
            console.log('Assinatura do locatário adicionada com sucesso ao PDF');
        } catch (error) {
            console.error('Erro ao adicionar assinatura do locatário:', error);
            doc.setFont('helvetica', 'normal');
            doc.text('____________________________________________', 15, y);
            y += 5;
            doc.text('[ASSINATURA DIGITAL DO LOCATÁRIO APLICADA]', 15, y);
            y += 15;
        }
    }
    
    // Rodapé de validação
    y += 10;
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(8);
    doc.text('Este documento foi assinado digitalmente através do sistema AssinaFácil.', 105, y, { align: 'center' });
    y += 5;
    doc.text('Assinaturas digitais válidas e verificáveis.', 105, y, { align: 'center' });
    
    return y;
}

// Função auxiliar para limpar dados base64 (deve estar disponível globalmente)
function limparDadosBase64(dados) {
    if (!dados || typeof dados !== 'string') {
        return null;
    }
    
    // Remover TODOS os caracteres %P e outros caracteres inválidos
    let dadosLimpos = dados.replace(/%P/g, '').replace(/[^A-Za-z0-9+/=]/g, '');
    
    // Remover prefixo data:image se existir
    if (dadosLimpos.includes('data:image')) {
        const partes = dadosLimpos.split(',');
        if (partes.length > 1) {
            dadosLimpos = partes[1];
        }
    }
    
    // Verificar se ainda contém caracteres %P após limpeza
    if (dadosLimpos.includes('%P')) {
        console.error('Ainda há caracteres %P após limpeza - dados rejeitados');
        return null;
    }
    
    // Verificar tamanho mínimo
    if (dadosLimpos.length < 100) {
        console.warn('Dados base64 muito pequenos');
        return null;
    }
    
    return dadosLimpos;
}

